# lineshader

Modified Line Shader giving it variable width.

Note that it only uses ellipse to draw circles.
Comment out the line starting with `shader(` to 
observe the default rendering.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/08/lineshader/thumb.png)
