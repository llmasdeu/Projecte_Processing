# lineshader2

Drawing lines of variable stroke-weight with a shader.

The shader is mostly the original line shader from Processing with
just two little changes: one to make the line width variable, and
another to modulate the color so it doesn't look flat.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/08/lineshader2/thumb.png)

