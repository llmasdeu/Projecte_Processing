# copycat_gears

During the Creative Code Jam (Berlin) sometimes we play the copy cat game.
Teams describe to each other an animated loop.
A describes a loop to B, and B describes a loop to A.
Then we code based on the description.
Finally we compare the original to the result.
A great exercise in observation, description and coding.

[OPENRNDR port](https://github.com/hamoid/openrndr-template/blob/master/src/main/kotlin/apps/copycat_gears.kt)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/10/copycat_gears/thumb.png)

