# maxImageSaturation

Shows images from a folder with maxed out saturation.
Just to find out how they look like.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/11/maxImageSaturation/thumb.jpg)

