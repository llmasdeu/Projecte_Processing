# bloomGames

Experimenting with shader based post processing using Thomas Diewald's Pixelflow library.

Move the mouse horizontally to control. Start on the right side of the screen then move left.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/11/bloomGames/thumb.jpg)

