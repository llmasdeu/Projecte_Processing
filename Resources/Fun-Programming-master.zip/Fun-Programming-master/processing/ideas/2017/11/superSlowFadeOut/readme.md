# superSlowFadeOut

A method for fading out the image very slowly. The speed is configurable in pixels per frame.
Slowest would be 1 pixel per frame.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/11/superSlowFadeOut/thumb.jpg)

