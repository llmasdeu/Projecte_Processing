# neighboors2

Some kind of game of incomplete life attempt, version 2

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/11/neighboors2/thumb.jpg)

