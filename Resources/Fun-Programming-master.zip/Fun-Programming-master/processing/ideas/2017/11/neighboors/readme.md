# neighboors

Some kind of game of incomplete life attempt, version 1

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/11/neighboors/thumb.jpg)

