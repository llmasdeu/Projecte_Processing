# avoidxmastree

Draws a xmas tree by filling a masked space (`bg.png`) with squiggly width-varying lines.
The lines grow trying to avoid colliding until they can no longer move forward.
At that point it adds a red dot at the beginning of the line.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/12/avoidxmastree/thumb.png)

