# avoidxmas

Choose a random point in the screen and start drawing a line there. 
If you are going to collide with an existing line or with the border of
the window, turn to avoid that. If there's no way to avoid collision,
respawn somewhere else and try again.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/12/avoidxmas/thumb.png)
