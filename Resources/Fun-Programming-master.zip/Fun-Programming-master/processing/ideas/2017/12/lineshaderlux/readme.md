# lineshaderlux

A bunch of circles moving across the screen.
Rendered with a custom shader for variable stroke
width and with two PixelFlow effects.

The circles move at non-constant speed, a bit like
frogs crossing the road.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/12/lineshaderlux/thumb.jpg)

