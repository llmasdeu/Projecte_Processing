# plot3Dorganic

A sketch that draws a huge number of lines of various lengths and colors 
all starting from the same position is space.

Press [space] to trigger a render, [s] to save the resulting image.

These images were all created with this program by slightly changing the
formula.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/05/plot3Dorganic/thumb.jpg)
