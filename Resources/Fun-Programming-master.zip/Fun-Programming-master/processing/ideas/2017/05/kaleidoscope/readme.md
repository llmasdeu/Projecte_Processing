# kaleidoscope

Shader based polar-coordinates effect applied to video playback.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2017/05/kaleidoscope/thumb.jpg)

