# noiseAdd

Draw pixels based on noise at different scales
to have both small details and large areas of color.
Contrast of  size.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2014/04/noiseAdd/thumb.jpg)
