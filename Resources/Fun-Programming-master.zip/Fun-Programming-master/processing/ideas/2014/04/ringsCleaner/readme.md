# ringsCleaner

Simple rings painted with circles.

Trying to have objects that are simultaneously in front and behind others,
as by default objects are either in front or behind.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2014/04/ringsCleaner/thumb.jpg)

