# envelope

Shows the use of an Envelope class. It's goal is to animate a value over time.
One can specify any number of values and durations of the transitions between
those values. Values are interpolated with easeInOutQuad. It's possible to
specify the number of repetitions of the sequence.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2014/07/envelope/thumb.png)

