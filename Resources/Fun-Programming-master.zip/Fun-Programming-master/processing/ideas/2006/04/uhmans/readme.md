# uhmans

The oldest Processing sketch in my collection, from 22.04.2006.

It represents humans colectives. They feel good when there is enough distance.
When they are too close there is conflict. 

One of the first times I used object oriented code. I remember it feeling quite strange :)
I was probably using https://github.com/processing/processing/releases/tag/processing-0112

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2006/04/uhmans/thumb.jpg)

