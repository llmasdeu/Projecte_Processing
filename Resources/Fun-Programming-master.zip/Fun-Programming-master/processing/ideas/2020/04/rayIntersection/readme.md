# rayIntersection

Geometry. Find out the intersection of two rays.

A ray has an origin (a location where it starts)
and a direction. It goes infinitely in that direction.

Like a laser in perfect vacuum.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2020/04/rayIntersection/thumb.png)

