# irregularLineBetweenTwoPoints

A method to draw an animated noise-bent line between two points.

Also shows how to create a square using polar coordinates. That is,
how to get the radius of a square for any given angle.

    float r = min(1/abs(cos(ang)), 1/abs(sin(ang)));    

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2020/03/irregularLineBetweenTwoPoints/thumb.jpg)
