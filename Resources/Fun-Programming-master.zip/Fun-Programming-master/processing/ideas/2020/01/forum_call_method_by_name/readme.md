# forum_call_method_by_name

In the Processing forum it was asked how to call a method
by name. Here's one example using reflection.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2020/01/forum_call_method_by_name/thumb.jpg)

