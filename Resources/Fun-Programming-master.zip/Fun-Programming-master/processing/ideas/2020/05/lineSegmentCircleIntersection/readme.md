# lineSegmentCircleIntersection

A function to calculate the intersection(s)
between a line segment and a circle.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2020/05/lineSegmentCircleIntersection/thumb.jpg)

