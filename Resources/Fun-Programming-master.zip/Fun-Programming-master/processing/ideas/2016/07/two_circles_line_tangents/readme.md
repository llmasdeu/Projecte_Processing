# two_circles_line_tangents

Interactive program showing the tangent lines that connect two circles.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2016/07/two_circles_line_tangents/thumb.png)

