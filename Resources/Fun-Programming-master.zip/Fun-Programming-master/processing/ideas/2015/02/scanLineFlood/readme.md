# scanLineFlood

A naive approach for filling closed shapes pixel by pixel.

Interactive. Click on the screen to fill an area.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/02/scanLineFlood/thumb.png)

