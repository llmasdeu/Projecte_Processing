# ellipso_rect

Animated loop based on code by Jerome Herr at
http://p5art.tumblr.com/post/120693457458/ellipsorect-code

I made it bouncy and added particles.

![](https://66.media.tumblr.com/73e9a1d8564b56ba65e6f2cbb45ea1cd/tumblr_npi0p0WK5f1qz62bdo2_r1_540.gifv)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/06/ellipso_rect/thumb.png)
