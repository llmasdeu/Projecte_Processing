# recursive_lines

I like creating depth by having parts of an image blurry and other parts sharp.

In this case, when the mouse is pressed, the screen is blurred by 1 pixel and
covered with a translucent layer of orange, making previously drawn shapes
become slightly "lost in fog", blurred and blended with the background.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/06/recursive_lines/thumb.jpg)

