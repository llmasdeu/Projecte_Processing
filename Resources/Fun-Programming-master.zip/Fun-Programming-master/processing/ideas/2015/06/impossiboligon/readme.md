# impossiboligon

Produces an animated loop cycling through rotating extruded polygons
of 3, 4, 5 and 100 sides.

The properties of the polygons are set manually (instead of mathematically)
so they match visually. I cared more about getting it done than about the
nobel prize.

![](https://66.media.tumblr.com/7fff0a02297c7d965010d57c63ab7d23/tumblr_npwnlzEhtR1qz62bdo1_r1_500.gifv)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/06/impossiboligon/thumb.png)

