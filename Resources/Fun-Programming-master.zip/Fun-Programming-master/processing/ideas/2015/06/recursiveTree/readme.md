# recursiveTree

Draws an animated loop of an aggresive generative tree.

Not meant for real time consumption but for producing an animated GIF file.

The [space] key randomizes the seed to produce different looking trees.

![](https://66.media.tumblr.com/b677146461982908ff532c0ebd50c9ca/tumblr_nqcg560OuQ1qz62bdo1_540.gifv)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/06/recursiveTree/thumb.png)

