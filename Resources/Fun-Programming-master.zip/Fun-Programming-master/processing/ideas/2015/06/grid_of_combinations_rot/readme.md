# grid_of_combinations_rot

A sketch I made for showing the students at FH Potsdam. 

Draws a grid of overlapping rotated triangles, blurs it, draws it again. 
That achieves some kind of bloom effect. Uses a limited color palette. 

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/06/grid_of_combinations_rot/thumb.png)

