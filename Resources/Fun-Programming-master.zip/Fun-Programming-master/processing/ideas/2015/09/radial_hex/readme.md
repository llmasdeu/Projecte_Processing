# radial_hex

Program that draws glowing curves quantized to 6 possible angles,
producing hexagonal shapes.

Mouse click to set the center of rotation.

[space] to clear

's' to save

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/09/radial_hex/thumb.jpg)
