I created a library for video export.

Find it at:

https://github.com/hamoid/video_export_processing
