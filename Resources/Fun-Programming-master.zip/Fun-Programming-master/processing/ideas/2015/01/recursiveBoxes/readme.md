# recursiveBoxes

A tiny program that creates complexity via recursion.
It exports an .obj file that I rendered using Blender.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/01/recursiveBoxes/thumb.jpg)

