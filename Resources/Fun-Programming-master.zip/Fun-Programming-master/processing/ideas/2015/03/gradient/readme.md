# gradient

Creating a simple gradient texture by coloring pixels. To be used as a gradient in other sketches.

(I didn't know how to do this with shaders at the time)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/03/gradient/thumb.jpg)

