# gradientPolygon

Making use of a generated gradient texture in polygons. I align the texture to the longest edge of the polygon.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/03/gradientPolygon/thumb.jpg)

