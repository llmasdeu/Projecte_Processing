# particlesNoise

Using the Nature of Code's Vehicle class, draw a number of particles leaving
traces on the screen. They move flocking, avoiding each other.

The drawn lines change opacity, thickness and brightness.


![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2015/12/particlesNoise/thumb.jpg)

