# sine_acid

Set the color of every pixel on the window based on multiple `sin()`
operations applied to the position of the pixel.

This is the kind of programs I used to write in the 90s :-)

Animated. Uses time in the formulas to have an ever changing effect.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2011/09/sine_acid/thumb.jpg)

