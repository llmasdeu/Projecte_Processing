# bezierFish

A program originally written in ActionScript (Flash) approximately in year 2000. This used to be my homepage for a while.
Ported to Processing in 2011. One of my first sketches.

It draws animated bezier curves in which start, end and control points follow different bezier curves themselves.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2011/05/bezierFish/thumb.png)

