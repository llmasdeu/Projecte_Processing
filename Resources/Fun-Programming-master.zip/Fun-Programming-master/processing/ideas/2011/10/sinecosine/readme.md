# sinecosine

"Spirograph", "String art" or "pin and thread art"?

Rotate two points around the center at different speeds.
Connect the two points with a line of varying color.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2011/10/sinecosine/thumb.png)

