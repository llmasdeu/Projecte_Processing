# EnvelopeGridTest

A grid version of my envelope class. It is used for animating collections of items simultaneously but with different
delays.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/11/EnvelopeGridTest/thumb.png)

