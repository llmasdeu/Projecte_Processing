# Flowers

Generate animated flowers when pressing the `space` key.
Press `s` to save an image.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/11/Flowers/thumb.png)
