# rotCubeGradient

Painting with the color of lights instead of using fill colors.

The reason to do that is to achieve more depth by painting with gradients instead of flat colors.

Light positions rotate smoothly but with regular jumps to create colors patterns in the drawn cubes.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/09/rotCubeGradient/thumb.png)

