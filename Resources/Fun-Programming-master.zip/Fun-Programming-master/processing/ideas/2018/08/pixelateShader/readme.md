# pixelateShader

Very minimal shader to pixelate your rendering. Allows setting the resolution using a uniform.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/08/pixelateShader/thumb.jpg)

