# PanZoom class

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/08/panZoomSketch/thumb.jpg)

A simple class that allows showing a larger PGraphics in a smaller viewport,
pan and zoom using the mouse.

This sketch shows 6 such viewports running simultaneously.

