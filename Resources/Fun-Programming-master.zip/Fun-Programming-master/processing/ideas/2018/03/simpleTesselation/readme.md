# simpleTesselation

A simple way to tesselate a convex polygon. If we have 7 points defining the contour,
then we can create triangles using these vertices: 012, 023, 034, 045, 056.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/03/simpleTesselation/thumb.png)

