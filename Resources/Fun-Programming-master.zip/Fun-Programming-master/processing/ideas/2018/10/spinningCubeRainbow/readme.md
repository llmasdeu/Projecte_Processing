# spinningCubeRainbow

Slowly rotating 3D cubes painting on a black background.
A black translucent line connecting the two cubes compensates
by subtracting light from the result.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/10/spinningCubeRainbow/thumb.jpg)

