# transparencyTestPShape

Test transparency in P3D mode 
with the hints `DISABLE_DEPTH_TEST`,
`DISABLE_DEPTH_SORT` and `DISABLE_DEPTH_MASK`.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/10/transparencyTestPShape/thumb.jpg)

