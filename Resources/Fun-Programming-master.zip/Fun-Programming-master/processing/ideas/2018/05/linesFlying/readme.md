# linesFlying

Written while flying.

Usage: Click. Then click again. Until you get a curve.

It will try to add a curve that starts and ends in previous curves
without intersecting them.

Examples painted with Gimp: 
[one](https://twitter.com/hamoid/status/999749957526663168), 
[two](https://twitter.com/hamoid/status/999405228729528320).

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2018/05/linesFlying/thumb.jpg)

