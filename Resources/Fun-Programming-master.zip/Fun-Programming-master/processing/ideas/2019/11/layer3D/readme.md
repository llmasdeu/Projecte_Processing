# layer3D

Shows how to work with an animated 3D layer with transparent
background which can be displayed multiple times.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/11/layer3D/thumb.jpg)
