# drawDonut

A simple method to create a ring-shaped PShape.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/11/drawDonut/thumb.jpg)
