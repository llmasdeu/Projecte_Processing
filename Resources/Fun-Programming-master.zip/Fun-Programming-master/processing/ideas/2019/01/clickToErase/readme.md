# clickToErase

A program that draws two layers and allows the user to interactively erase the top layer by dragging the mouse
while holding the left mouse button down.

It shows an issue with [linear gamma color space](https://ninedegreesbelow.com/photography/test-for-linear-processing.html#painting)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/01/clickToErase/thumb.jpg)

