# bumpInCircle

Draws circles with a bump. The bump is located at an angle defined by the variable `high`.
The width of the bump is defined by `overlap`, which is modulated over time to make it more
dynamic, while using an offset so not all circles are wide or narrow at the same time, but
in sequence instead.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/01/bumpInCircle/thumb.png)
