# ShaderTextureCube

Simple shader-based generative texture applied to a rotating 3D cube.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/08/ShaderTextureCube/thumb.jpg)
