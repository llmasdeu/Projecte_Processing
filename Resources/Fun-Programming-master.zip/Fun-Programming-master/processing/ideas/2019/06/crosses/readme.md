# crosses

A program to generate the cover for the [Creative Code Stammtisch 62](https://creativecodeberlin.github.io/Stammtisch/2019/06/07/ccs062.html).
Uses 3 point lights to create color gradients.
Uses an exponential distribution so there are few large shapes and many small ones.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/06/crosses/thumb.jpg)

