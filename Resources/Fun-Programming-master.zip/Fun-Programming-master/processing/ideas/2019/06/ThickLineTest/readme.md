# ThickLineTest

A class for drawing pShape-based lines of variable thickness.
The lines are made out of 4D points: x, y for position, z for depth and w for thickness.
The program exports an .obj file when pressing the `s` key.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/06/ThickLineTest/thumb.jpg)

