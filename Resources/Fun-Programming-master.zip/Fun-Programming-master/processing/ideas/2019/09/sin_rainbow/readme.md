# sin_rainbow

A basic example of how to get all color hues without using the HSB mode.
The variable `t` sets the hue. Then R, G and B are calculated based on `t`
by using the `sin()` function.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/09/sin_rainbow/thumb.jpg)
