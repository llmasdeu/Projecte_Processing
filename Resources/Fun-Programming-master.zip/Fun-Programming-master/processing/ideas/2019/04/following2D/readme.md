# following2D

A simple class for an object to follow a 2D target and reduce speed when getting near.
If the target changes location suddenly the moving object turns towards the new target smoothly.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/04/following2D/thumb.png)

