# variableThicknessLines

Shader based line drawing that produces lines that go from zero strokeWeight to full strokeWeight and back to zero.
The program allows reloading the shader by pressing '0', and loading other shaders (if they were present) by pressing
other number keys.

Press `r` to randomize, `s` to save.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2019/04/variableThicknessLines/thumb.png)

