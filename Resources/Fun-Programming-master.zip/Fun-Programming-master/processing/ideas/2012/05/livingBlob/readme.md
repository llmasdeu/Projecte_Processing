# livingBlob

Variation from the sketch "blob" from April 2012.

It uses a texture. Unfortunately it lost its "blobiness"
because `curveVertex()` does not implement uv coordinates
for using textures, so I switched to `vertex()`.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2012/05/livingBlob/thumb.jpg)

