# walking_cube

The goal of this sketch is to calculate the right vertical position 
of a cube (or a square) when it "walks" (rotates) forward and backwards
on a hard surface.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2012/04/walking_cube/thumb.jpg)

