# blob

In this sketch I test `curveVertex`

Notice that three Vertices are drawn twice to make it a closed shape.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2012/04/blob/thumb.jpg)

