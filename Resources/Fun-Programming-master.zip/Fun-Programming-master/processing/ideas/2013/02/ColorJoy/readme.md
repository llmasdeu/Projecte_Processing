# ColorJoy

Vertical lines covering the whole screen. Their hues
depend on the sine of `noise()` of time.

See it live at [hamoid.com](https://hamoid.com/code/2013-colorjoy/)

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2013/02/ColorJoy/thumb.jpg)

