# RotationContinuity

Create animated patterns by drawing a very long line on the
surface of a sphere.

A video of it in [YouTube](https://www.youtube.com/watch?v=AmTHjBQc37Y).

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2013/02/RotationContinuity/thumb.png)

