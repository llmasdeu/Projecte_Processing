# BWJoy

Grayscale variation of my sketch called ColorJoy.

Draw vertical lines covering the whole screen.
The brightness of each depends on time, `noise()` and calls to `sin()`.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2013/02/BWJoy/thumb.jpg)

