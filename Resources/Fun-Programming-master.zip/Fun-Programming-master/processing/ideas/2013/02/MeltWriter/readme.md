# MeltWriter

Interactive wet paint simulation experiment. Uses the pixel array. A more efficient approach would use shaders instead.

![](https://raw.githubusercontent.com/hamoid/Fun-Programming/master/processing/ideas/2013/02/MeltWriter/thumb.png)

