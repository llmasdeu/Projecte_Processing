- [creative coding sketches](https://github.com/hamoid/Fun-Programming)
- [fun programming tutorials](fun-programming/)

